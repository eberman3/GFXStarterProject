import * as React from 'react';
import * as ReactDOM from 'react-dom';
import "./Main.scss";
import { NodeCollectionStore } from './stores/NodeCollectionStore';
import { RootStore } from './stores/RootStore';
import { StaticTextNodeStore } from './stores/StaticTextNodeStore';
import { VideoNodeStore } from './stores/VideoNodeStore';
import { CollectionNodeStore } from './stores/CollectionNodeStore';
import { FreeFormCanvas } from './views/freeformcanvas/FreeFormCanvas';
import { ImageNodeStore } from './stores/ImageNodeStore';
import { PDFNodeStore } from './stores/PDFNodeStore';
import { WebNodeStore } from './stores/WebNodeStore';
import { InkNodeStore } from './stores/InkNodeStore';



const mainNodeCollection = new NodeCollectionStore();
ReactDOM.render((
    <div>
        <h1>Dash Web</h1>
        <FreeFormCanvas store={mainNodeCollection} type = "base"/>
    </div>), document.getElementById('root'));



