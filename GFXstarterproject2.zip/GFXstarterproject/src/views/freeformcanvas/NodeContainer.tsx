import { observer } from "mobx-react";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";
import { StaticTextNodeStore } from "../../stores/StaticTextNodeStore";
import { VideoNodeStore } from "../../stores/VideoNodeStore";
import { TextNodeView } from "../nodes/TextNodeView";
import { VideoNodeView } from "../nodes/VideoNodeView";
import { ImageNodeStore } from "../../stores/ImageNodeStore";
import { ImageNodeView } from "../nodes/ImageNodeView";
import { PDFNodeStore } from "../../stores/PDFNodeStore";
import { PDFNodeView } from "../nodes/PDFNodeView";
import { WebNodeStore } from "../../stores/WebNodeStore";
import { WebNodeView } from "../nodes/WebNodeView";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { CollectionNodeView } from "../nodes/CollectionNodeView";
import { InkNodeStore } from "../../stores/InkNodeStore";
import { InkNodeView } from "../nodes/InkNodeView";
import React = require("react");
import { FreeFormCanvas } from "./FreeFormCanvas";
import { NodeStore } from "../../stores/NodeStore";
import { observable, action } from "mobx";
import {Line} from 'react-lineto';
import { LinkNodeStore } from "../../stores/LinkNodeStore";
import { LinkNodeView } from "../nodes/LinkNodeView";

// The Node Container class renders all nodes. This class contains 
// the node-container, which contains all nodes within it. The render
// function loops through each Node in the node array, evaluates which 
// type of node it is, and returns an instance  of that type of node.

interface IProps {
    store: NodeCollectionStore
}


@observer
export class NodeContainer extends React.Component<IProps> {

    public item: NodeStore;
    public item2: NodeStore;
    
    @observable
    public Name: string = "node-container";

    render() {
        return (
            <>
            <div className="node-container">
                {this.props.store.Nodes.map(nodeStore => {
                    if (nodeStore instanceof StaticTextNodeStore) {
                        return (<TextNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as StaticTextNodeStore}parentStore={this.props.store}/> )
                    } else if (nodeStore instanceof VideoNodeStore) {
                        return (<VideoNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as VideoNodeStore} parentStore={this.props.store} />)
                    } else if (nodeStore instanceof ImageNodeStore) {
                        return (<ImageNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as ImageNodeStore} parentStore={this.props.store}/>)
                    } else if (nodeStore instanceof PDFNodeStore) {
                        return (<PDFNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as PDFNodeStore}parentStore={this.props.store}/>)
                    } else if (nodeStore instanceof WebNodeStore) {
                        return (<WebNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as WebNodeStore} parentStore={this.props.store}/>)
                    } else if (nodeStore instanceof CollectionNodeStore) {
                        return (<CollectionNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as CollectionNodeStore} parentStore={this.props.store}/>)
                    } else if (nodeStore instanceof InkNodeStore) {
                        return (<InkNodeView removeChild={this.props.store.removeChild} key={nodeStore.Id} store={nodeStore as InkNodeStore} parentStore={this.props.store}/>)
                    } else if (nodeStore instanceof LinkNodeStore) {
                        return (<LinkNodeView key={nodeStore.Id} store={nodeStore as LinkNodeStore} parentstore={this.props.store} />)
                    }

                })}
            </div>
            </>
        );
    }
}