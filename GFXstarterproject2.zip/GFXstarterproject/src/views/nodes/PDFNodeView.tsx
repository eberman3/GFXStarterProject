import { observer } from "mobx-react";
import { PDFNodeStore } from "../../stores/PDFNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./PDFNodeView.scss";
import React = require("react");
import { PDFObject } from 'react-pdfobject';
import { Document, Page } from 'react-pdf';
import { NodeStore } from "../../stores/NodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

import { PDFReader } from 'reactjs-pdf-reader'

// PDFNodeView imports the attributes of the PDfNodeStore.
// The PDFNodeView renders a PDF node, which renders a PDF through the 
// npm module react-pdf. The node also contains a top bar.

interface IProps {
    store: PDFNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class PDFNodeView extends React.Component<IProps> {

    private _numPages = null;
    
    //onDocumentLoadSuccess stores the number of pages in the document after it is rendered 
    onDocumentLoadSuccess = ({ numPages }) => {
        this._numPages = numPages
    }

    //The OnPointerDown method allows the contentEditable feature of the title to function.
    onPointerDown = (e:React.PointerEvent):void => {
        e.stopPropagation();
    }

    duplicate = () => {
        this.props.parentStore.AddNode(new PDFNodeStore({ X: this.props.store.X+this.props.store.Width+300, Y: this.props.store.Y, Title: this.props.store.Title, Url: this.props.store.Url }));
    }

    //ChangePage function incriments or decrements the page number if possible.
    changePage(dir: string) {
        if (dir == "forward") {
            if (this.props.store.pageNumber + 1 < this._numPages) {
                this.props.store.pageNumber += 1
            }
        } else {
            if (this.props.store.pageNumber - 1 > 0) {
                this.props.store.pageNumber -= 1
            }
        }
    }

    //renders of PDF node using react-pdf.
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;

        return (
            <div className="node text-node" onPointerDown={this.onPointerDown} style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height}}>
                <TopBar store={store} {...this.props} />
                <button className = "duplicate" onClick={this.duplicate}> Duplicate </button>
                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title}</h3>
                        <div className="PDF">
                            <p>Page {store.pageNumber} of {this._numPages}</p>
                            <button onClick= {() => this.changePage("backward")}> Previous Page </button>
                            <button onClick= {() => this.changePage("forward")}> Next Page </button>
                            <Document file={store.Url} onLoadSuccess={this.onDocumentLoadSuccess}>
                                <Page pageNumber={store.pageNumber} scale={1+store.Width/1000} width={260+store.Width} />
                            </Document> 
                            
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}