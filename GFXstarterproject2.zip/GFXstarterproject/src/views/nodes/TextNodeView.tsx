import { observer } from "mobx-react";
import { observable, action } from "mobx";
import { StaticTextNodeStore } from "../../stores/StaticTextNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import React = require("react");
import ReactQuill from 'react-quill'
import { NodeStore } from "../../stores/NodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

import { LinkNodeStore } from "../../stores/LinkNodeStore";


// TectNodeView imports the attributes of the TextNodeStore.
// The TextNodeView renders a text node, which displays rich editable 
// text using the ReactQuill npm module. The node also contains a top bar.

interface IProps {
    store: StaticTextNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class TextNodeView extends React.Component<IProps> {
    private editorRef = React.createRef<ReactQuill>();

    duplicate = () => {
        this.props.parentStore.AddNode(new StaticTextNodeStore({ X: this.props.store.X+this.props.store.Width+300, Y: this.props.store.Y, Title: this.props.store.Title, Text: this.props.store.Text }));
    }

    //renders a TextNode with rich text editing.
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;
        return (
            <div className="node text-node" style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height }}> 
                <TopBar store={store} {...this.props} />
                <button className = "duplicate" onClick={this.duplicate}> Duplicate </button>
                <div className="scroll-box">
                    <div className="content" onClick={() => this.editorRef.current.focus() }>
                        <h3 className="title" >{store.Title}</h3>
                        {/* <p className="paragraph">{store.Text}</p> */}
                        <link rel="stylesheet" href="//cdn.quilljs.com/1.2.6/quill.snow.css"></link>
                        <ReactQuill ref={this.editorRef} value={store.Text} />
                    </div>
                </div>
            </div>
            
            );
    }
}