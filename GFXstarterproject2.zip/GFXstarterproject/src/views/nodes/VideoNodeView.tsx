import { observer } from "mobx-react";
import { VideoNodeStore } from "../../stores/VideoNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./VideoNodeView.scss";
import React = require("react");
import { NodeStore } from "../../stores/NodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

// VideoNodeView imports the attributes of the VideoNodeStore.
// The VideoNodeView renders a video node, which contain an embedded
// video. The node also contains a top bar.

interface IProps {
    store: VideoNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}


@observer
export class VideoNodeView extends React.Component<IProps> {

    duplicate = () => {
        this.props.parentStore.AddNode(new VideoNodeStore({ X: this.props.store.X+this.props.store.Width+300, Y: this.props.store.Y, Title: this.props.store.Title, Url: this.props.store.Url }));
    }

    //The OnPointerDown method allows the contentEditable feature of the title to function.
    onPointerDown = (e:React.PointerEvent):void => {
        e.stopPropagation();
    }

    //renders of a video node displaying the video found at a url 
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;
        return (
            <div className="node text-node" onPointerDown={this.onPointerDown} style={{transform: store.Transform, width: 300+store.Width, height: 300+store.Height}}>
                <TopBar store={store} {...this.props} />
                <button className = "duplicate" onClick={this.duplicate}> Duplicate </button>

                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title}</h3>
                        <video src={store.Url} controls />
                    </div>
                </div>
            </div>
        );
    }
}