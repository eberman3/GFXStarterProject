import { observer } from "mobx-react";
import { action } from "mobx"
import { NodeStore } from "../../stores/NodeStore";
import React = require("react");
import { Line } from 'react-lineto';
import { LinkNodeStore } from "../../stores/LinkNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";
import "./LinkNodeView.scss";
import { TopBar } from "./TopBar";
import ReactDOM = require("react-dom");
import { FreeFormCanvas } from "../freeformcanvas/FreeFormCanvas";

// LinkNodeView imports the attributes of the LinkNodeStore.
// The LinkNodeView renders a line from one node to another, using the 
// imported npm module react-lineto. The line moves based on the location of the 
// two linked nodes and the movement of the free form canvas.

interface IProps {
    store: LinkNodeStore;
    parentstore: NodeCollectionStore;
}


@observer
export class LinkNodeView extends React.Component<IProps> {

    //The onPointerdown event for LinkNodeView uses the distance formula to calculate
    //which of the two linked nodes is farther from where on the line the user clicked.
    //The screen then pans to this node to re-center it.
    onPointerDown = (e:React.PointerEvent): void => {
        const setWidth:number = 300;
        e.stopPropagation();
        //distance formula
        let distancefirstNode:number = Math.sqrt(Math.pow(e.screenX-this.props.parentstore.deltaX-this.props.store.firstNode.X,2)+
        Math.pow(e.screenY-this.props.parentstore.deltaY-this.props.store.firstNode.Y,2))
        let distancesecondNode:number = Math.sqrt(Math.pow(e.screenX-this.props.parentstore.deltaX-this.props.store.secondNode.X,2)+
        Math.pow(e.screenY-this.props.parentstore.deltaY-this.props.store.secondNode.Y,2))
        let closeNode:NodeStore = null;
        if (distancefirstNode >= distancesecondNode) {
            closeNode = this.props.store.secondNode;

        } else {
            closeNode = this.props.store.firstNode;
        }
        //resetting parent store X and Y
        //this.props.parentstore.X=closeNode.X-(closeNode.Width+setWidth)-window.innerWidth/4;
        //this.props.parentstore.Y=closeNode.Y-(closeNode.Width+setWidth)-window.innerHeight/4;
        
        this.props.parentstore.deltaX= closeNode.X-(closeNode.Width+setWidth)-window.innerWidth/4;
        this.props.parentstore.deltaY= closeNode.Y-(closeNode.Width+setWidth)-window.innerHeight/4;

    }  

    //A line from the first linked node to the second linked node is rendered using react-lineto.
    render() {
        let store = this.props.store;
        let parentStore = this.props.parentstore;
        console.log(parentStore.Type);
        //var firstNode = document.getElementById(store.firstNode.Id);
        //console.log("!!!!", firstNode);

        //const NodeOne = store.firstNode as unknown as Element
        //console.log(NodeOne.getBoundingClientRect());

        //console.log(this.props.store.NodeLeft);
        //console.log(this.props.store.NodeTop);

        // console.log(document.getElementById(this.props.store.firstNode.Id))
        // if (document.getElementById(this.props.store.firstNode.Id)) {
        //     var rect = document.getElementById(this.props.store.firstNode.Id).getBoundingClientRect()
        //     console.log(rect.top, rect.right, rect.bottom, rect.left);
        // }
        let change = 20;
        if (parentStore.Type == "collection") {
            change = 300;
        }
        return (
            
            <div className="link-node" onPointerDown={this.onPointerDown} style={{ transform: store.Transform } }>
                <Line className = "line" 
                x0={((store.firstNode.X+change)+(parentStore.deltaX + (parentStore.X - parentStore.deltaX)))*parentStore.Scale} 
                y0={((store.firstNode.Y+change)+(parentStore.deltaY + (parentStore.Y - parentStore.deltaY)))*parentStore.Scale} 
                x1={((store.secondNode.X+change)+(parentStore.deltaX + (parentStore.X - parentStore.deltaX)))*parentStore.Scale} 
                y1={((store.secondNode.Y+change)+(parentStore.deltaY + (parentStore.Y - parentStore.deltaY)))*parentStore.Scale} 
                borderWidth={5} borderColor="black"  preserveMarkerAspect={false}> </Line> 
            </div>
        )
    }
}
