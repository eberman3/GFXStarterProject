import { observer } from "mobx-react";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./CollectionNodeView.scss";
import React = require("react");
import { NodeStore } from "../../stores/NodeStore";
import { FreeFormCanvas } from "../freeformcanvas/FreeFormCanvas";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

// CollectionNodeView imports the attributes of the CollectionNodeStore.
// The CollectionNodeView renders a collection node, which contain an embedded
// freeformcanvas. The node also contains a top bar.

interface IProps {
    store: CollectionNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}


@observer
export class CollectionNodeView extends React.Component<IProps> {

    mainNodeCollection: NodeCollectionStore;

    constructor(props) {
        super(props);
        this.mainNodeCollection = new NodeCollectionStore;
        this.props.store.Type = 'collection';
    }

    //The OnPointerDown method allows the contentEditable feature of the title to function.
    onPointerDown = (e:React.PointerEvent):void => {
        e.stopPropagation();
    }

    duplicate = () => {
        this.props.parentStore.AddNode(new CollectionNodeStore({ X: this.props.store.X+this.props.store.Width+300, Y: this.props.store.Y, Title: this.props.store.Title}));
    }


    //A collection node is rendered using a freeform canvas.
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;
        return (
            <div className="node collection-node" onPointerDown={this.onPointerDown} style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height}}>
                <TopBar store={store} {...this.props} />
                <button className = "duplicate" onClick={this.duplicate}> Duplicate </button>
                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title}</h3>
                        <div className='dash-canvas'>

                            <FreeFormCanvas store ={new NodeCollectionStore()} type="collection" /> 
                            {/* <FreeFormCanvas store ={new NodeCollectionStore} /> */}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}