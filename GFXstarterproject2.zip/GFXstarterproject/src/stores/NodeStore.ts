import { computed, observable, action, ObservableMap } from "mobx";
import { Utils } from "../Utils";

// The node store is the parent class of all types of Nodes (Collection, Image, Ink,
// PDF, Text, Video, and Web.) This store contains the attributes of all the nodes
// on the FreeFormCanvas, such as location, size, and id. This class also contains
// the @computed method transform which is called to alter the location of a node based on 
// user dragging (done in TopBar.)

export class NodeStore {

    public Id: string = Utils.GenerateGuid();

    @observable
    public Type: string = 'node';

    @observable
    public X: number = 0;

    @observable
    public Y: number = 0;

    @observable
    public Width: number = 0;

    @observable
    public Height: number = 0;

    @observable
    public Linked: boolean = false;

    @observable
    public LinkedNodes: NodeStore[] = new Array<NodeStore>();

    @observable
    public Links: NodeStore[] = new Array<NodeStore>();

    @observable
    public Color: string = 'white';

    @observable
    public linkCount: number = 0;

    @computed
    public get Transform(): string {
       return "translate(" + this.X + "px, " + this.Y + "px)" ;
    }

    @computed
    public get NodeLeft(): number {
        console.log(this.Id)
        if (document.getElementById(this.Id)) {
            return document.getElementById(this.Id).getBoundingClientRect().left
        }
    }

    @computed
    public get NodeTop(): number {
        if (document.getElementById(this.Id)) {
            return document.getElementById(this.Id).getBoundingClientRect().top
        }
    }
}