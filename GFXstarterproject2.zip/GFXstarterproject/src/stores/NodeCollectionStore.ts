import { computed, observable, action } from "mobx";
import { NodeStore } from "./NodeStore";

// The Node Collection Node store is a sub class of NodeStore. This class
// contains the attributes of the collection. This includes Scale and the
// nodes within the collection. This method contains @action events and @computed
// events to modify the scale of the screen (done on wheel events), add nodes (called
// on button click of new node instantiation), and removing a child node from a collection.
// The remove child method is inherited by each NodeView class.

export class NodeCollectionStore extends NodeStore {

    @observable
    public Scale: number = 1;

    @observable
    public Nodes: NodeStore[] = new Array<NodeStore>();

    @observable
    public LinkedNodes: NodeStore[] = new Array<NodeStore>();

    @observable
    public deltaX: number = 0;

    @observable
    public deltaY: number = 0;

    @computed
    public get Transform(): string {
        return "translate(" + this.X + "px," + this.Y + "px) scale(" + this.Scale + "," + this.Scale + ")";
    }

    @action
    public AddNodes(stores: NodeStore[]): void {
        stores.forEach(store => this.Nodes.push(store));
    }

    @action
    public AddNode(store: NodeStore): void {
        this.Nodes.push(store);
    }

    @action
    public linkNode(store: NodeStore): void {
        this.LinkedNodes.push(store);
    }

    //this class takes in a list of Nodes and removes them from the Nodes array. 
    // There is no output.
    @action
    public removeChild = (...stores: NodeStore[]): void => {
        stores.forEach(store => {
            const index = this.Nodes.indexOf(store);
            this.Nodes.splice(index, 1);
        });
    }

    
}