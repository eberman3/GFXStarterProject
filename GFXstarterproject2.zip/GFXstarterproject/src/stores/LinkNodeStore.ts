import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The Link Node store is a sub class of NodeStore. This class contains the 
// attributes of all Links on the screen. Links are displayed after two Nodes' 
// linked attributes have been turned on, on button click. This class contains
// the specifications for the npm module react-lineto. This class is instantiated
// upon button click in the FreeFormCanvas class.

export class LinkNodeStore extends NodeStore {

    constructor(initializer: Partial<LinkNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    // @observable
    // public X1: number;

    // @observable
    // public X2: number;

    // @observable
    // public Y1: number;

    // @observable
    // public Y2: number;

    @observable
    public firstNode: NodeStore;

    @observable
    public secondNode: NodeStore;


}