import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The PDF Node store is a sub class of NodeStore. This class contains the 
// attributes of all PDFs nodes on the screen. All PDFs nodes are created with
// necessary inputs Title and Url. This class is instantiated upon button click 
// in the FreeFormCanvas class.

export class PDFNodeStore extends NodeStore {;

    constructor(initializer: Partial<PDFNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    @observable
    public Title: string;

    @observable
    public Url: string;

    @observable
    public pageNumber: number=1;

}