import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The Video Node store is a sub class of NodeStore. This class contains the 
// attributes of all imaVideoge nodes on the screen. All Video nodes are created with
// necessary inputs Title and Url. This class is instantiated upon button click 
// in the FreeFormCanvas class.

export class VideoNodeStore extends NodeStore {

    constructor(initializer: Partial<VideoNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    @observable
    public Title: string;

    @observable
    public Url: string;

}