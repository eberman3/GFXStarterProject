import { computed, observable, action } from "mobx";
import { Utils } from "../Utils";

// The node store is the parent class of all types of Nodes (Collection, Image, Ink,
// PDF, Text, Video, and Web.) This store contains the attributes of all the nodes
// on the FreeFormCanvas, such as location, size, and id. This class also contains
// the @computed method transform which is called to alter the location of a node based on 
// user dragging (done in TopBar.)

export class NodeStore {

    public Id: string = Utils.GenerateGuid();

    @observable
    public X: number = 0;

    @observable
    public Y: number = 0;

    @observable
    public Width: number = 0;

    @observable
    public Height: number = 0;

    @observable
    public Linked: boolean = false;

    @observable
    public LinkedNodes: NodeStore[] = new Array<NodeStore>();

    @observable
    public Links: NodeStore[] = new Array<NodeStore>();

    @computed
    public get Transform(): string {
       return "translate(" + this.X + "px, " + this.Y + "px)" ;
    }
}