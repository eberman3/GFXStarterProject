import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The Web Node store is a sub class of NodeStore. This class contains the 
// attributes of all Web nodes on the screen. All Web nodes are created with
// necessary inputs Title and Url. This class is instantiated upon button click 
// in the FreeFormCanvas class.

export class WebNodeStore extends NodeStore {

    constructor(initializer: Partial<WebNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    @observable
    public Title: string;

    @observable
    public Url: string;

}