import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The Collection Node store is a sub class of NodeStore. This class contains the 
// attributes of all nested collections on the screen. This class is instantiated
// upon button click in the FreeFormCanvas class.

export class CollectionNodeStore extends NodeStore {

    constructor(initializer: Partial<CollectionNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    @observable
    public Title: string;

}