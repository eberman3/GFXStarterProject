import { observable } from "mobx";
import { NodeStore } from "./NodeStore";

// The Ink Node store is a sub class of NodeStore. This class contains the 
// attributes of all Ink Nodes on the screen. This class contains the 
// specifications for the npm module react-canvas-draw. This class is instantiated
// upon button click in the FreeFormCanvas class.

export class InkNodeStore extends NodeStore {

    constructor(initializer: Partial<InkNodeStore>) {
        super();
        Object.assign(this, initializer);
    }

    @observable
    public Title: string;

        onChange: null;
        loadTimeOffset: 5;
        lazyRadius: 30;
        brushRadius: 12;
        brushColor: "#444";
        catenaryColor: "#0a0302";
        gridColor: "rgba(150,150,150,0.17)";
        hideGrid: false;
        canvasWidth: 400;
        canvasHeight: 400;
        disabled: false;
        imgSrc: "";
        saveData: null;
        immediateLoading: false;
        hideInterface: false;
      
}