import { observer } from "mobx-react";
import { ImageNodeStore } from "../../stores/ImageNodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./ImageNodeView.scss";
import React = require("react");
import { NodeStore } from "../../stores/NodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

// ImageNodeView imports the attributes of the ImageNodeStore.
// The ImageNodeView renders an image node, which renders the image found at an
// inputted URL. The node also contains a top bar.

interface IProps {
    store: ImageNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class ImageNodeView extends React.Component<IProps> {

    //The OnPointerDown method allows the contentEditable feature of the title to function.
    onPointerDown = (e:React.PointerEvent):void => {
        e.stopPropagation();
    }

    //an image node is rendered using a url from the store.
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;
        return (
            <div className="node text-node" onPointerDown={this.onPointerDown} style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height}}>
                <TopBar store={store} {...this.props} />
                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title}</h3>
                        <img src={store.Url} />
                    </div>
                </div>
            </div>
        );
    }
}