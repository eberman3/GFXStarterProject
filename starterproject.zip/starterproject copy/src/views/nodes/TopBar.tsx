import { observer } from "mobx-react";
import { NodeStore } from "../../stores/NodeStore";
import "./NodeView.scss";
import React = require("react");
import { TextNodeView } from "./TextNodeView";
import { VideoNodeView } from "./VideoNodeView";
import { ImageNodeView } from "./ImageNodeView";
import { PDFNodeView } from "./PDFNodeView";
import { WebNodeView } from "./WebNodeView";
import { CollectionNodeView } from "./CollectionNodeView";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { LinkNodeStore } from "../../stores/LinkNodeStore";

// TopBar is displayed on every nodeView. TopBar contains the move functionality
// for each node. Top Bar also contains the resize functionality via a button on
// the top left hand corner. On the top right hand corner, there is a button to 
// delete the node. There is also a button to turn the link functionality on for a 
// specific node. Once two nodes' link functionality has been turned on, the nodes 
// can be linked by clicking the button on the freeform canvas.

interface IProps {
    store: NodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class TopBar extends React.Component<IProps> {

    private _isPointerDown = false;

    //when Pointer is held down, onPointerMove is called.
    onPointerDown = (e: React.PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = true;
        document.removeEventListener("pointermove", this.onPointerMove);
        document.addEventListener("pointermove", this.onPointerMove);

        document.removeEventListener("pointerup", this.onPointerUp);
        document.addEventListener("pointerup", this.onPointerUp);
    }

    //called to stop resizing when cursor is released.
    onPointerDownDrag = (e: React.PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = true;
        document.removeEventListener("pointermove", this.onPointerResize);
        document.addEventListener("pointermove", this.onPointerResize);

        document.removeEventListener("pointerup", this.onPointerUpDrag);
        document.addEventListener("pointerup", this.onPointerUpDrag);
    }

    //calls removeChild @action method from NodeStore to remove the node from the Nodes List.
    //onCancel also removes all links to the Node.
    onCancel = () => {
        this.props.removeChild(this.props.store);
        {this.props.store.Links.map(nodeStore => {
            this.props.removeChild(nodeStore)
        })}
    }

    //called to stop Node movement when cursor is released.
    onPointerUp = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = false;
        document.removeEventListener("pointermove", this.onPointerMove);
        document.removeEventListener("pointerup", this.onPointerUp);
    }

    onPointerUpDrag = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = false;
        document.removeEventListener("pointermove", this.onPointerResize);
        document.removeEventListener("pointerup", this.onPointerUp);
    }

    //onPointerMove moves the node by dragging the TopBar. This method has been
    //modified to account for changes in scale. The Node still drags porportionally
    //to cursor movement when the scale has been changed.
    onPointerMove = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        if (!this._isPointerDown) {
            return;
        }
        this.props.store.X += e.movementX / this.props.parentStore.Scale;
        this.props.store.Y += e.movementY / this.props.parentStore.Scale;

    }

    //resizes the width and height of the node, called upon button drag.
    onPointerResize = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        if (!this._isPointerDown) {
            return;
        }
        this.props.store.Width += e.movementX;
        this.props.store.Height += e.movementY;
    }

    //on button click, node's link functionality is toggled on.
    //the linked node is added to an array attribute of each link. For example, when node A is linked to node B,
    //Node B is added to Node A's LinkedNodes array and Node A is added to Node B's LinkedNodes array.
    //Node A and Node B are both added to the Node Collection Store's Linked Nodes array.
    link = (): void => {
        this.props.store.Linked = true;
        this.props.parentStore.LinkedNodes.push(this.props.store);
        if (this.props.parentStore.LinkedNodes.length % 2 == 0) {
            this.props.parentStore.AddNode(new LinkNodeStore({firstNode: this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-2], secondNode: this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-1]}));
            this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-2].LinkedNodes.push(this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-1])
            this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-1].LinkedNodes.push(this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-2])

            this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-1].Links.push(this.props.parentStore.Nodes[this.props.parentStore.Nodes.length-1])
            this.props.parentStore.LinkedNodes[this.props.parentStore.LinkedNodes.length-2].Links.push(this.props.parentStore.Nodes[this.props.parentStore.Nodes.length-1])

        }

    }


    render() {
        return (
        <div className="top" onPointerDown={this.onPointerDown}>
            <button className = "link" onClick={this.link}> Link </button>
            <button className = "quitbutton" onClick={this.onCancel}> X </button>
            <button className = "resizebutton" onPointerDown={this.onPointerDownDrag}> Drag to Resize </button>
        </div>
        )
    }
}
