import { observer } from "mobx-react";
import { observable, action } from "mobx";
import { InkNodeStore } from "../../stores/InkNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./InkNodeView.scss";
import React = require("react");
import CanvasDraw from "react-canvas-draw";
import { NodeStore } from "../../stores/NodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

// InkNodeView imports the attributes of the InkNodeStore.
// The InkNodeView renders a ink node, which contain an imported npm module
// react-canvas-draw. The node also contains a top bar.

interface IProps {
    store: InkNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class InkNodeView extends React.Component<IProps> {

    //The OnPointerDown method allows the user to hold down the pointer to draw on the canvas. 
    onPointerDown = (e:React.PointerEvent): void => {
        e.stopPropagation();
        document.removeEventListener("pointerup", this.onPointerUp);
        document.addEventListener("pointerup", this.onPointerUp);
    }

    //OnPointerUp removes the focus from the canvas so the node can move normally.
    onPointerUp = (e:PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        document.removeEventListener("pointerup", this.onPointerUp);
    }

    //Renders a ink node using CanvasDraw.
    render() {
        const { store } = this.props; 
        let parentStore = this.props.parentStore;
        return (
            <div className="node text-node" style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height }} onPointerDown={this.onPointerDown}> 
                <TopBar store={store} {...this.props} />
                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title} </h3>
                        <div className = "canvas">
                            <CanvasDraw/> 
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}