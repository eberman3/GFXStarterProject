import { observer } from "mobx-react";
import { WebNodeStore } from "../../stores/WebNodeStore";
import "./NodeView.scss";
import { TopBar } from "./TopBar";
import "./WebNodeView.scss";
import React = require("react");
import { NodeStore } from "../../stores/NodeStore";
import { CollectionNodeStore } from "../../stores/CollectionNodeStore";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";

// WebNodeView imports the attributes of the WebNodeStore.
// The WebNodeView renders a web node, which contain an embedded
// website using iframe. The node also contains a top bar.

interface IProps {
    store: WebNodeStore;
    parentStore: NodeCollectionStore;
    removeChild: (...childToRemove: NodeStore[]) => void;
}

@observer
export class WebNodeView extends React.Component<IProps> {

    //The OnPointerDown method allows the contentEditable feature of the title to function.
    onPointerDown = (e:React.PointerEvent):void => {
        e.stopPropagation();
    }

    //renders a webnode displaying the webpage stored at a url
    render() {
        const { store } = this.props; 

        let parentStore = this.props.parentStore;
        return (
            <div className="node text-node" onPointerDown={this.onPointerDown} style={{ transform: store.Transform, width: 300+store.Width, height: 300+store.Height}}>
                <TopBar store={store} parentStore={parentStore} {...this.props} />
                <div className="scroll-box">
                    <div className="content">
                        <h3 className="title" contentEditable={true}>{store.Title}</h3>
                        {/* <input type="text" placeholder="Search.."> </input> */}
                        <div className="Web">
                            <iframe src={store.Url} ></iframe>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}