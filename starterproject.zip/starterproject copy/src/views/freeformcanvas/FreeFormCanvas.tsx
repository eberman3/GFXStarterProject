import { observer } from "mobx-react";
import { NodeCollectionStore } from "../../stores/NodeCollectionStore";
import "./FreeFormCanvas.scss";
import { NodeContainer } from "./NodeContainer";
import React = require("react");
import { action } from "mobx";
import { StaticTextNodeStore } from '../../stores/StaticTextNodeStore';
import { VideoNodeStore } from '../../stores/VideoNodeStore';
import { PDFNodeStore } from '../../stores/PDFNodeStore';
import { CollectionNodeStore } from '../../stores/CollectionNodeStore';
import { WebNodeStore } from '../../stores/WebNodeStore';
import { InkNodeStore } from '../../stores/InkNodeStore';
import { ImageNodeStore } from '../../stores/ImageNodeStore';
import { LinkNodeStore } from "../../stores/LinkNodeStore";
import { NodeStore } from "../../stores/NodeStore";

// The freeform canvas class renders an instance of the node container and all 
// buttons to create new nodes, links, and alter the view. This class also
// contains functions to move the screen on pointer drag and to change the 
// scale of the nodes on mouse wheel (pinching the trackpad). When the LINK 
// button is clicked, an instance of the LinkNodeView class is instantiated.
// When the view is changed to grid, the locations of the nodes are altered.

interface IProps {
    store: NodeCollectionStore
}

@observer
export class FreeFormCanvas extends React.Component<IProps> {

    private _isPointerDown: boolean;
    private _grid: boolean=false;
    private _typesort: boolean=false;
    public item: NodeStore;
    private _xCoordinates: number[] = [];
    private _yCoordinates: number[] = [];
    private _xCoordinatestype: number[] = [];
    private _yCoordinatestype: number[] = [];
    private _Width: number[] = [];
    private _Height: number[] = [];
    private _tempx: number;
    private _tempy: number;
    private _margin:number = 350;
    
    //onPointerDown calls the OnPointerMove event to move the free form canvas once the user
    //begins dragging the cursor across the screen.
    onPointerDown = (e: React.PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = true;
        document.removeEventListener("pointermove", this.onPointerMove);
        document.addEventListener("pointermove", this.onPointerMove);
        document.removeEventListener("pointerup", this.onPointerUp);
        document.addEventListener("pointerup", this.onPointerUp);
    }

    //The on wheel event changes the scale of each node according to the deltaY of 
    //pinching the trackpad (or scrolling the wheel on a mouse).
    @action
    onWheel = (e: React.WheelEvent<HTMLDivElement>): void => {
        e.preventDefault();
        const scale = 1 - (e.deltaY / 100);
        this.props.store.Scale *= scale;
    }

    //onPointerUp stops the movement of the canvas when the user releases the cursor.
    onPointerUp = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        this._isPointerDown = false;
        document.removeEventListener("pointermove", this.onPointerMove);
        document.removeEventListener("pointerup", this.onPointerUp);
    }

    //onPointerMove re-sets the X and Y locations of the freeform canvas based on dragging the cursor.
    onPointerMove = (e: PointerEvent): void => {
        e.stopPropagation();
        e.preventDefault();
        if (!this._isPointerDown) {
            return;
        }
        this.props.store.X += e.movementX;
        this.props.store.Y += e.movementY;
        
        this.props.store.deltaX += e.movementX;
        this.props.store.deltaY += e.movementY;
    }

    //the set coordinate method determines the x and y location of any new node that is created on the screen.
    //This X and Y location is dependent upon view form. For free form views, the X and Y location
    //are random. For grid view, the location of a new node is dependent upon the location of the previous node.
    //For typesport view, the location of a new node is dependent upon the node's type.
    setCoordinates = (): void => {
        const maxXY:number = 800;
        const maxXrow:number = 1100;
        let x:number = Math.random() * maxXY; //random view default new node coordinates
        let y:number = Math.random() * maxXY;
        if (this._grid) { //find the next location in the grid300
            if (this.props.store.Nodes[this.props.store.Nodes.length-1].X < maxXrow) {
                y = this.props.store.Nodes[this.props.store.Nodes.length-1].Y;
                x = this.props.store.Nodes[this.props.store.Nodes.length-1].X+this._margin;
            } else {
                x = this.props.store.Nodes[this.props.store.Nodes.length-4].X;
                y = this.props.store.Nodes[this.props.store.Nodes.length-1].Y+this._margin;
            }
            this._xCoordinates.push(Math.random() * maxXY);
            this._yCoordinates.push(Math.random() * maxXY);
            this._Width.push(0);
            this._Height.push(0);
        }  else if (this._typesort) {
            this._xCoordinatestype.push(Math.random() * maxXY);
            this._yCoordinatestype.push(Math.random() * maxXY);
            this._Width.push(0);
            this._Height.push(0);
        }
        this._tempx = x;
        this._tempy = y;

    }

    //The addNode method takes in a string containing which type of node to instantiate. 
    //It then instantiates that node and renders it on the canvas.
    addNode = (str: String) => {
        this.setCoordinates();
        let x:number = this._tempx;
        let y:number = this._tempy;
        if (str == 'text') {
            this.props.store.AddNode(new StaticTextNodeStore({ X: x, Y: y, Title: "Text Node Title", Text: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?" }));
        } else if (str == 'image') {
            this.props.store.AddNode(new ImageNodeStore({ X:x, Y: y, Title: "Image Node Title", Url: "https://i.etsystatic.com/5551332/r/il/644e9d/1852658302/il_570xN.1852658302_2yzz.jpg"}));
        } else if (str == 'video') {
            this.props.store.AddNode(new VideoNodeStore({ X: x, Y: y, Title: "Video Node Title", Url: "http://cs.brown.edu/people/peichman/downloads/cted.mp4" }));
        } else if (str == 'pdf') {
            this.props.store.AddNode(new PDFNodeStore({ X: x, Y: y, Title: "PDF Node Title", Url: "http://www.orimi.com/pdf-test.pdf" })); //"http://solar-center.stanford.edu/activities/SunColor/Drive-By-Science-What-Color-is-the-Sun.pdf"
        } else if (str == 'web') {
            this.props.store.AddNode(new WebNodeStore({ X: x, Y: y, Title: "Web Node Title", Url: "https://www.bbc.com" }));
        } else if (str == 'collection') {
            this.props.store.AddNode(new CollectionNodeStore({ X: x, Y: y, Title: "Collection Node Title" }));
        } else if (str == 'ink') {
            this.props.store.AddNode(new InkNodeStore({ X: x, Y: y, Title: "Ink Node Title" }));
        }
        if (this._typesort) {
            this.sortbytype();
        }

    }

    //Grid places the nodes in a Xx4 grid in the order in which the nodes were created.
    //Grid() loops through each node, re-setting its x, y, Width, and Height values.
    grid = () => {
        this._typesort = false;
        const xmargin:number = 100;
        const maxNum:number = 3;
        let x = 100;
        let y = 100;
        let numinrow = 0;
        {
            this.props.store.Nodes.map(nodeStore => {
                this._xCoordinates.push(nodeStore.X);
                this._yCoordinates.push(nodeStore.Y);
                this._Width.push(nodeStore.Width);
                this._Height.push(nodeStore.Height);
                nodeStore.X = x;
                nodeStore.Y = y;
                nodeStore.Width = 0;
                nodeStore.Height = 0;
                if (numinrow < maxNum) {
                    x += this._margin;;
                    numinrow += 1;
                }
                else {
                    x = xmargin;
                    y += this._margin;;
                    numinrow = 0;
                }
            })
        }
        this._grid = true;
    }

    //Sortbytype creates a column for each type of node and places the nodes of that corresponding
    //type in that column. It does so by re-setting the Node's X, Y, Width, and Height.
    sortbytype = () => {
        this._grid = false;
        let x:number = 100;
        let y:number = 100;
        let ymargin:number = 200;
        let countNodeType:number[] = [0,0,0,0,0,0,0];
        {
            this.props.store.Nodes.map(nodeStore => {
                this._xCoordinatestype.push(nodeStore.X);
                this._yCoordinatestype.push(nodeStore.Y);
                this._Width.push(nodeStore.Width);
                this._Height.push(nodeStore.Height);
                nodeStore.Width = 0;
                nodeStore.Height = 0;
                if (nodeStore instanceof StaticTextNodeStore) {
                    nodeStore.X = x;
                    nodeStore.Y = y+countNodeType[0]*ymargin;
                    countNodeType[0] += 1;
                } else if (nodeStore instanceof VideoNodeStore) {
                    nodeStore.X = x+this._margin;
                    nodeStore.Y = y+countNodeType[1]*ymargin;
                    countNodeType[1] += 1;
                } else if (nodeStore instanceof ImageNodeStore) {
                    nodeStore.X = x+(this._margin*2);
                    nodeStore.Y = y+countNodeType[2]*ymargin;
                    countNodeType[2] += 1;
                } else if (nodeStore instanceof PDFNodeStore) {
                    nodeStore.X = x+(this._margin*3);
                    nodeStore.Y = y+countNodeType[3]*ymargin;
                    countNodeType[3] += 1;
                } else if (nodeStore instanceof WebNodeStore) {
                    nodeStore.X = x+(this._margin*4);
                    nodeStore.Y = y+countNodeType[4]*ymargin;
                    countNodeType[4] += 1;
                } else if (nodeStore instanceof CollectionNodeStore) {
                    nodeStore.X = x+(this._margin*5);
                    nodeStore.Y = y+countNodeType[5]*ymargin;
                    countNodeType[5] += 1;
                } else if (nodeStore instanceof InkNodeStore) {
                    nodeStore.X = x+(this._margin*6);
                    nodeStore.Y = y+countNodeType[6]*ymargin;
                    countNodeType[6] += 1;
                }
            })
        }
        this._typesort = true;
    }


    //ungrid places the Nodes back in their previous position before the button was clicked.
    //It does so by re-setting the X,Y, width and height of the Node to the stored values before 
    //the view was changed.
    ungrid = () => {
        {
            this.props.store.Nodes.map(nodeStore => {
                if (this._grid) {
                    nodeStore.X = this._xCoordinates.pop();
                    nodeStore.Y = this._yCoordinates.pop();
                } else if (this._typesort) {
                    nodeStore.X = this._xCoordinatestype.pop();
                    nodeStore.Y = this._yCoordinatestype.pop();
                }
                nodeStore.Width = this._Width.pop();
                nodeStore.Height = this._Height.pop();
            })
        }
        this._grid = false;
        this._typesort = false;
    }

    render() {
        let store = this.props.store;
        return (
            <React.Fragment>
                <div className="freeformcanvas-container" onPointerDown={this.onPointerDown} onWheel={this.onWheel}>
                <   div className="freeformcanvas" style={{ transform: store.Transform }}>
                        <NodeContainer store={store} />
                    </div>
                    <div className="buttons">
                        <p> To link two nodes, click "link" on the nodes you would like to connect! </p>
                        <p> Click the link to pan from node to node. </p>
                        <button className="button" onClick={() => this.addNode('text')}> Add a text node </button>
                        <button className="button" onClick={() => this.addNode('image')}> Add an image node </button>
                        <button className="button" onClick={() => this.addNode('video')}> Add a video node </button>
                        <button className="button" onClick={() => this.addNode('pdf')}> Add a PDF node </button>
                        <button className="button" onClick={() => this.addNode('web')}> Add a Web node </button>
                        <button className="button" onClick={() => this.addNode('ink')}> Add a Ink node </button>
                        <button className="button" onClick={() => this.addNode('collection')}> Add a Collection node </button>
                        <p> View Forms: </p>
                        <button className="button" onClick={() => this.grid()}> Grid view </button>
                        <button className="button" onClick={() => this.sortbytype()}> Type sort view </button>
                        <button className="button" onClick={() => this.ungrid()}> Free form view </button>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}