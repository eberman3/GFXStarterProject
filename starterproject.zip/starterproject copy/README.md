# Starter Project
Install Node.js, then, from the project directory, run

* `npm install`
* `npm start`
* goto `http://localhost:1050` in Google Chrome Canary (https://www.google.com/chrome/canary/) or Firefox

Note: `npm start` compiles and runs the application in debug mode, meaning that when you edit and save the source files, it will re-compile  and reload the browser window automatically.
